/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.jakstab;

import java.util.Objects;

/**
 *
 * @author yexin
 */
public class PDSRules {
    String start;
    String to;
    String inStack;
    String[] toStack=new String [2];
    public PDSRules(String start,String to)
    {
        this.start=start;
        this.to=to;
        //this.inStack=stack;
        this.toStack[0]=" ";
        this.toStack[1]=" ";
    }
    public PDSRules(String start, String to, String stack, String toStack)
    {
        this.start=start;
        this.to=to;
        this.inStack=stack;
        this.toStack[0]=toStack;
        this.toStack[1]=" ";
    }
    public PDSRules(String start,String to, String stack, String toStack0, String toStack1)
    {
        this.start=start;
        this.to=to;
        this.inStack=stack;
        this.toStack[0]=toStack0;
        this.toStack[1]=toStack1;
    }
    @Override
     public boolean equals(Object o)
    {
        if(!(o instanceof PDSRules)){
            return false;}
        
        PDSRules r=(PDSRules)o;
        
        return this.start.equals(r.start)&&this.to.equals(r.to)&&this.inStack.equals(r.inStack)&&this.toStack[0].equals(r.toStack[0])&&this.toStack[1].equals(r.toStack[1]);
        
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 89 * hash + Objects.hashCode(this.start);
        hash = 89 * hash + Objects.hashCode(this.to);
        hash = 89 * hash + Objects.hash(this.inStack);
        return hash;
    }

}
