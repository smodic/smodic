/**
 *  ReturnInstruction.java - Copyright 2007-2015 Johannes Kinder <kinder@in.tum.de>
 *  This file is part of the Jakstab project.
 */
package org.jakstab.asm;

public interface ReturnInstruction extends BranchInstruction {
}
