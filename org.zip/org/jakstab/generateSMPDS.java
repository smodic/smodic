/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.jakstab;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.jakstab.asm.AbsoluteAddress;

/**
 *
 * @author yexin
 */
public class generateSMPDS {
    
    ArrayList<String> SMPDSRulesList=new ArrayList<String>();
    
    public generateSMPDS(Map<AbsoluteAddress, String> PDSPoints,Map<String, ArrayList<PDSRules>>rulesMap,HashMap<Long,String> stackContentsMap){
    
        for (Map.Entry<Long,String> entry : stackContentsMap.entrySet()) {  
            
            String str=entry.getValue();
            
            for(Map.Entry<String, ArrayList<PDSRules>> baseEntry: rulesMap.entrySet())
            {
                Iterator it =baseEntry.getValue().iterator();
                
                while(it.hasNext())
                {
                    PDSRules ruleP=(PDSRules)it.next();
                    
                    if(ruleP.toStack[0].equals(" ")&&ruleP.toStack[1].equals(" ")) // epsilon case
                    {
                        StringBuilder sb=new StringBuilder();
                        
                        sb.append("R"+SMPDSRulesList.size()+1);
                        
                        sb.append(":<"+ruleP.start+","+str+"><"+ruleP.to+","+" >");
                        
                        SMPDSRulesList.add(sb.toString());
                                
                        }
                    else if((!ruleP.toStack[0].equals(" ")&&(ruleP.toStack[1].equals(" "))))// case of one stack to one stack
                    {
                        StringBuilder sb=new StringBuilder();
                        
                        sb.append("R"+SMPDSRulesList.size()+1);
                        
                        sb.append(":<"+ruleP.start+","+str+"><"+ruleP.to+","+str+">");
                        
                        SMPDSRulesList.add(sb.toString());
                    }
                    else if((!ruleP.toStack[0].equals(" ")&&(!ruleP.toStack[1].equals(" "))))// case of one stack to one stack
                    {
                        StringBuilder sb=new StringBuilder();
                        
                        sb.append("R"+SMPDSRulesList.size()+1);
                        
                        sb.append(":<"+ruleP.start+","+str+"><"+ruleP.to+","+ruleP.toStack[0]+str+">");
                        
                        SMPDSRulesList.add(sb.toString());
                    }
                    
                }
            }
  
    
          }  
}
    public void toTxtString(){
        
    }
}
