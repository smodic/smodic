/*
* 
 * Original codes  from the  Jakstab 
 * Modified for use with the SMODIC project. All modifications 
 *Xin Ye <joyexin@gmail.com>

 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, see <http://www.gnu.org/licenses/>.
 */
package org.jakstab;

import java.awt.Color;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

import org.jakstab.analysis.*;
import org.jakstab.analysis.explicit.VpcTrackingAnalysis;
import org.jakstab.asm.AbsoluteAddress;
import org.jakstab.asm.BranchInstruction;
import org.jakstab.asm.Instruction;
import org.jakstab.asm.ReturnInstruction;
import org.jakstab.asm.SymbolFinder;
import org.jakstab.cfa.AsmCFG;
import org.jakstab.cfa.CFAEdge;
import org.jakstab.cfa.CFAEdge.Kind;
import org.jakstab.cfa.ControlFlowGraph;
import org.jakstab.cfa.Location;
import org.jakstab.cfa.RTLLabel;
import org.jakstab.cfa.VpcLocation;
import org.jakstab.rtl.statements.BasicBlock;
import org.jakstab.rtl.statements.RTLGoto;
import org.jakstab.rtl.statements.RTLHalt;
import org.jakstab.rtl.statements.RTLSkip;
import org.jakstab.rtl.statements.RTLStatement;
import org.jakstab.transformation.VpcCfgReconstruction;
import org.jakstab.util.*;


import com.google.common.collect.HashMultimap;
import com.google.common.collect.SetMultimap;
import java.util.Map.Entry;
import org.jakstab.asm.Immediate;
import org.jakstab.asm.Operand;
import org.jakstab.asm.x86.X86CallInstruction;
import org.jakstab.asm.x86.X86CondJmpInstruction;
import org.jakstab.asm.x86.X86JmpInstruction;
import org.jakstab.asm.x86.X86MemoryOperand;
import org.jakstab.asm.x86.X86PCRelativeAddress;
import org.jakstab.asm.x86.X86Register;
import org.jakstab.asm.x86.X86RetInstruction;
import org.jakstab.rtl.expressions.RTLNumber;
import smodic.SMPDSTransitions;
import smodic.callInstruction;
import smodic.changingTransition;
import smodic.normalPDSRule;
import smodic.pushList;

/**
 * Writes various graphs from a program structure.
 * 
 * @author Johannes Kinder
 */
public class ProgramGraphWriter {

	private static final Logger logger = Logger.getLogger(ProgramGraphWriter.class);
	private Program program;
	
	private Set<Location> mustLeaves;
        
        SetMultimap<AbsoluteAddress, CFAEdge> gobalBranchEdges=null;
        
        SMPDSTransitions SMPDS=new SMPDSTransitions();
        
        Map<AbsoluteAddress,Instruction> changingInstrList=new HashMap<AbsoluteAddress,  Instruction>();
        
        List<callInstruction> callList=new ArrayList<callInstruction>();
        
        public Map<AbsoluteAddress, List<String>> addrRulesRelation=new HashMap<AbsoluteAddress, List<String>> (); //this is used for construction of changing rules
        public  Map<String,List<String>> propControlLoc =new HashMap<String,List<String>>();
        
        public Map<String,List<String>> negPropControlLoc=new HashMap<String,List<String>>();
                
        List<pushList> pushlist=new ArrayList<pushList>(); // similar to callList. It is for the generation of SM-PDS.
        
        List<AbsoluteAddress> returnAddr=new ArrayList<AbsoluteAddress>();
        
        List<String> expValues=new ArrayList<String>();
        
        Map<String, String> gammaSet=new HashMap<String, String>();
        
        public String initialControlLoc;
        
        public String initialStackValue;
        
        public Map<String,AbsoluteAddress> locationAddressMap=new HashMap <String,AbsoluteAddress>(); //corresponding to addressConLocation.
        
       public   Map<String, List<String>> locationTransitions=new HashMap<String, List<String>>(); // stores each locations corresponding transitions
        
       public Map<String, changingTransition> allCrules = new HashMap<String, changingTransition>();// not only to use in one scope. This is initial transition set
    
       public Map<String, normalPDSRule> allNrules = new HashMap<String, normalPDSRule>();
        
        public  Map<AbsoluteAddress,String> addressConLocation=new HashMap<AbsoluteAddress,String>(); //This is to store the control location. key is the address and String is the control location of SM-PDS
        
       public Map<AbsoluteAddress, X86Register>  pushInstrList=new HashMap<AbsoluteAddress, X86Register>();
       
       public HashSet<String> intialSet=new HashSet<String>();
        
         Map<AbsoluteAddress, AbsoluteAddress>  popInstrList=new HashMap<AbsoluteAddress, AbsoluteAddress>();
         
         Map<AbsoluteAddress, List<AbsoluteAddress>>  retInstrList=new HashMap<AbsoluteAddress, List<AbsoluteAddress>>();// more than one target
         
         Map<AbsoluteAddress, List<AbsoluteAddress>>  cjmpInstrList=new HashMap<AbsoluteAddress, List<AbsoluteAddress>>(); //more than one target
        
         Map<AbsoluteAddress, List<AbsoluteAddress>>  jmpInstrList=new HashMap<AbsoluteAddress, List<AbsoluteAddress>>(); //more than one target
         
         Map<AbsoluteAddress, AbsoluteAddress>  restInstrList=new HashMap<AbsoluteAddress, AbsoluteAddress>();

	public ProgramGraphWriter(Program program) {
		this.program = program;

                
		ControlFlowGraph cfg = program.getCFG();
                
                
		
		mustLeaves = new HashSet<Location>();
		
		// Find locations which have an incoming MUST edge, but no outgoing one
		for (Location l : cfg.getNodes()) {
			boolean foundMust = false;
			for (CFAEdge e : cfg.getInEdges(l)) {
				foundMust |= e.getKind() == Kind.MUST;
			}
			
			if (!foundMust) 
				continue;
			
			foundMust = false;
			for (CFAEdge e : cfg.getOutEdges(l)) {
				foundMust |= e.getKind() == Kind.MUST;
			}
			
			if (!foundMust) {
				mustLeaves.add(l);
			}
			
		}
		
		if (!mustLeaves.isEmpty())
			logger.debug("Leaves of MUST-analysis: " + mustLeaves);
		
	}
        
        public void SMPDSWriter(String filename) throws IOException
        {
            try{
             FileWriter oWriter=new FileWriter(filename+"_smpds"); // for writing SM-PDS
             
             StringBuilder sb=new StringBuilder();
             
             for( Map.Entry<String, normalPDSRule> entry:allNrules.entrySet())
             {
                 sb.append(entry.getKey());
                 sb.append(":<");
                // ((normalPDSRule)entry.getValue()).
                 sb.append(((normalPDSRule)entry.getValue()).start);
                 sb.append(",");
                 sb.append(((normalPDSRule)entry.getValue()).iStack+"><");
                 sb.append(((normalPDSRule)entry.getValue()).to);
                 sb.append(",");
                 for(int i=0;i<((normalPDSRule)entry.getValue()).oStack.size();i++)
                 {
                     
                     sb.append(((normalPDSRule)entry.getValue()).oStack.get(i));
                 }
                 sb.append(">");
             }
             
             for( Map.Entry<String, changingTransition> entry:allCrules.entrySet())
             {
                 sb.append(entry.getKey());
                 sb.append(":");
                // ((normalPDSRule)entry.getValue()).
                 sb.append(((changingTransition)entry.getValue()).start);
                
                 sb.append(((changingTransition)entry.getValue()).to);
                 sb.append(((changingTransition)entry.getValue()).oLabel);
                sb.append(((changingTransition)entry.getValue()).nLabel);
                 
             }
             
             oWriter.write(sb.toString());
             
             System.out.printf("There are "+ allCrules.size()+allNrules.size() + "rules" +'\n');
             
             oWriter.close();
            } catch (IOException e) {
			logger.fatal(e);
			return;}
        }
        public void computeChangingTransitionRule()
        {
            Iterator iter = changingInstrList.entrySet().iterator();
            while (iter.hasNext()) {
            Entry<AbsoluteAddress,  Instruction> entry=(Entry<AbsoluteAddress,  Instruction>)iter.next();
            Instruction instr=entry.getValue();
            
             List<String> addrRuleList=new ArrayList<String>();
             
            Operand op=instr.getOperand(0);
            
                   if(op instanceof Immediate) 
                   {
                      int newOpcode=((Immediate) op).getNumber().intValue();
                      
                      Instruction newInstr=null;
                      
                      newInstr=program.getNewInstruction( (AbsoluteAddress)instr.getOperand(1),newOpcode);
              
                      String csLoc=addressConLocation.get(entry.getKey());
                      String sLoc=addressConLocation.get((AbsoluteAddress)instr.getOperand(1));
                      
                     Iterator<String> it= addrRulesRelation.get((AbsoluteAddress)instr.getOperand(1)).iterator();
                     
                     while(it.hasNext())
                     {
                         if(newInstr.toString().contains("jmp"))
                         {
                             
                             Operand oper =newInstr.getOperand(0);
                             
                             AbsoluteAddress to=null;
                             
                             if(oper instanceof AbsoluteAddress)
                             {
                                  to=(AbsoluteAddress) oper;
                             }
                             else if(oper instanceof X86PCRelativeAddress)
                             {
                                 to=new AbsoluteAddress(((AbsoluteAddress)instr.getOperand(1)).getValue()+newInstr.getSize()+ ((X86PCRelativeAddress) oper).getDisplacement());
                             }
                             else
                             {
                                 System.out.print("Cannot solve the target address of the new instruction."+'\n');
                                  System.out.print("We make an approximation."+'\n');
                                  to =new AbsoluteAddress(((AbsoluteAddress)instr.getOperand(1)).getValue()+newInstr.getSize());
                                  
                             }
                            // AbsoluteAddress to =new AbsoluteAddress(((AbsoluteAddress)instr.getOperand(1)).getValue()+newInstr.getSize());
                             
                             String oldID=it.next();
                             
                            normalPDSRule nl= allNrules.get(oldID);
                            
                            String str= nl.getInStack();
                            
                            List<String> ls=new ArrayList<String>();
                            
                            ls.add(str);
                            
                            String newRuleID="R"+allNrules.size()+allCrules.size();
                            
                            normalPDSRule r=new normalPDSRule(sLoc,addressConLocation.get(to),str,ls,newRuleID);
                            
                            allNrules.put(newRuleID, r);
                            
                             String cid="R"+ allNrules.size()+allNrules.size();
                             
                             changingTransition ct=new changingTransition(csLoc,addressConLocation.get(new AbsoluteAddress(entry.getKey().getValue()+instr.getSize())),oldID,newRuleID);
                             
                             allCrules.put(cid, ct);
                             
                             addrRuleList.add(cid);
                             
                             intialSet.add(cid);
                            
                         }
                         else //the target remains the same.
                         {
                            AbsoluteAddress to =new AbsoluteAddress(((AbsoluteAddress)instr.getOperand(1)).getValue()+newInstr.getSize());
                             
                            String oldID=it.next();
                             
                            normalPDSRule nl= allNrules.get(oldID);
                            
                            String str= nl.getInStack();
                            
                            List<String> ls=new ArrayList<String>();
                            
                            ls.add(str);
                            
                            String newRuleID="R"+allNrules.size()+allCrules.size();
                            
                            normalPDSRule r=new normalPDSRule(sLoc,addressConLocation.get(to),str,ls,newRuleID);
                            
                            allNrules.put(newRuleID, r);
                            
                             String cid="R"+ allNrules.size()+allNrules.size();
                             
                             changingTransition ct=new changingTransition(csLoc,addressConLocation.get(new AbsoluteAddress(entry.getKey().getValue()+instr.getSize())),oldID,newRuleID);
                             
                             allCrules.put(cid, ct);
                             
                             addrRuleList.add(cid);
                             
                             intialSet.add(cid);
                         }
                     }
                      
                     
                      
                      //computeTransitionRule( (AbsoluteAddress)instr.getOperand(0),newInstr, );
                   }
                   else
                   {
                       System.out.print("The new opcode is not supported yet"+'\n');
                       instr=program.getAssemblyMap().get(entry.getKey());
                   }
                  addrRulesRelation.put(entry.getKey(), addrRuleList);
            }
               
        }
        
        public void computeTransitionRule( Map<AbsoluteAddress, Set<RTLNumber>> pushRegister)
        {
            List<String> transList=new ArrayList<String>();
            
            for(Map.Entry<AbsoluteAddress, List<AbsoluteAddress>> entry:jmpInstrList.entrySet())
            {
                 List<AbsoluteAddress> values=entry.getValue();
                 
                String start=addressConLocation.get(entry.getKey());
                
                List<String> ls=new ArrayList<String>();
                
                for(int i=0;i<values.size();i++)
                {
                    String to=addressConLocation.get(values.get(i));
                    
                    for(Map.Entry<String, String> stackValues:gammaSet.entrySet())
                    {
                        String str=stackValues.getValue();
                        
                        List<String> oStack=new ArrayList();
                        
                        oStack.add(str);
                        
                        String ruleID="R"+allCrules.size()+allNrules.size();
                        
                        normalPDSRule jmp=new normalPDSRule(start, to,str, oStack,ruleID);
                        
                        allNrules.put(ruleID, jmp);
                        
                        intialSet.add(ruleID);
                        
                        ls.add(ruleID);
                    }
                }
                
                if(!addrRulesRelation.containsKey(entry.getKey()))
                
                         addrRulesRelation.put(entry.getKey(), ls);
                else
                {
                    transList=addrRulesRelation.get(entry.getKey());
                    
                    transList.addAll(ls);
                    
                    addrRulesRelation.put(entry.getKey(), transList);
                }
                
            }
            for(Map.Entry<AbsoluteAddress, List<AbsoluteAddress>> entry:retInstrList.entrySet())
            {
                 List<AbsoluteAddress> values=entry.getValue();
                 
                String start=addressConLocation.get(entry.getKey());
                
                List<String> ls=new ArrayList<String>();
                
                for(int i=0;i<values.size();i++)
                {
                    String to=addressConLocation.get(values.get(i));
                    
                    for(Map.Entry<String, String> stackValues:gammaSet.entrySet())
                    {
                        String str=stackValues.getValue();
                        
                        List<String> oStack=new ArrayList();
                        
                        oStack.add(" ");
                        
                        String ruleID="R"+allCrules.size()+allNrules.size();
                        
                        normalPDSRule jmp=new normalPDSRule(start, to,str, oStack,ruleID);
                        
                        allNrules.put(ruleID, jmp);
                        
                        ls.add(ruleID);
                        
                        intialSet.add(ruleID);
                    }
                }
                
                // addrRulesRelation.put(entry.getKey(), ls);
                if(!addrRulesRelation.containsKey(entry.getKey()))
                
                         addrRulesRelation.put(entry.getKey(), ls);
                else
                {
                    transList=addrRulesRelation.get(entry.getKey());
                    
                    transList.addAll(ls);
                    
                    addrRulesRelation.put(entry.getKey(), transList);
                }
                
            }
            for(Map.Entry<AbsoluteAddress, AbsoluteAddress> entry:restInstrList.entrySet())
            {
                //AbsoluteAddress values=entry.getValue();
                 
                String start=addressConLocation.get(entry.getKey());
                
                 List<String> ls=new ArrayList<String>();
              
                 String to=addressConLocation.get(entry.getValue());
                    
                    for(Map.Entry<String, String> stackValues:gammaSet.entrySet())
                    {
                        String str=stackValues.getValue();
                        
                        List<String> oStack=new ArrayList();
                        
                        oStack.add(str);
                        
                        String ruleID="R"+allCrules.size()+allNrules.size();
                        
                        normalPDSRule rest=new normalPDSRule(start, to,str, oStack,ruleID);
                        
                        allNrules.put(ruleID, rest);
                        
                        ls.add(ruleID);
                        
                        intialSet.add(ruleID);
                    }
                    
                   //  addrRulesRelation.put(entry.getKey(), ls);
                   if(!addrRulesRelation.containsKey(entry.getKey()))
                
                         addrRulesRelation.put(entry.getKey(), ls);
                else
                {
                    transList=addrRulesRelation.get(entry.getKey());
                    
                    transList.addAll(ls);
                    
                    addrRulesRelation.put(entry.getKey(), transList);
                }
            }
            
            for(Map.Entry<AbsoluteAddress, AbsoluteAddress> entry:popInstrList.entrySet())
            {
                //AbsoluteAddress values=entry.getValue();
                 
                String start=addressConLocation.get(entry.getKey());
                
               List<String> ls=new ArrayList<String>();
                 String to=addressConLocation.get(entry.getValue());
                    
                    for(Map.Entry<String, String> stackValues:gammaSet.entrySet())
                    {
                        String str=stackValues.getValue();
                        
                        List<String> oStack=new ArrayList();
                        
                        oStack.add(" ");
                        
                        String ruleID="R"+allCrules.size()+allNrules.size();
                        
                        normalPDSRule pop=new normalPDSRule(start, to,str, oStack,ruleID);
                        
                        allNrules.put(ruleID, pop);
                        
                        ls.add(ruleID);
                        
                        intialSet.add(ruleID);
                    }
                  //  addrRulesRelation.put(entry.getKey(), ls);
                  if(!addrRulesRelation.containsKey(entry.getKey()))
                
                                addrRulesRelation.put(entry.getKey(), ls);
                       else
                       {
                           transList=addrRulesRelation.get(entry.getKey());

                           transList.addAll(ls);

                           addrRulesRelation.put(entry.getKey(), transList);
                       }
            }
            for(int i=0;i<callList.size();i++)
            {
               callInstruction call= callList.get(i);
               
                String start=addressConLocation.get(call.source);
                
                String to =addressConLocation.get(call.target);
                
                 List<String> ls=new ArrayList<String>();
                
                    for(Map.Entry<String, String> stackValues:gammaSet.entrySet())
                    {
                        String str=stackValues.getValue();
                        
                        List<String> oStack=new ArrayList();
                        
                        oStack.add(gammaSet.get(call.reAddr.toNumericConstant().toHexString()));
                        
                        oStack.add(str);
                        
                        String ruleID="R"+allCrules.size()+allNrules.size();
                        
                        normalPDSRule callins=new normalPDSRule(start, to,str, oStack,ruleID);
                        
                        allNrules.put(ruleID, callins);
                        
                        ls.add(ruleID);
                        
                        intialSet.add(ruleID);
                    }
                   //  addrRulesRelation.put(call.source, ls);
                     if(!addrRulesRelation.containsKey(call.source))
                
                         addrRulesRelation.put(call.source, ls);
                else
                {
                    transList=addrRulesRelation.get(call.source);
                    
                    transList.addAll(ls);
                    
                    addrRulesRelation.put(call.source, transList);
                }
            }
            
            for(int i=0;i<pushlist.size();i++)
            {
               pushList push= pushlist.get(i);

                String start=addressConLocation.get(push.source);
                
                String to =addressConLocation.get(push.target);
                
                 List<String> ls=new ArrayList<String>();
                
                    for(Map.Entry<String, String> stackValues:gammaSet.entrySet())
                    {
                        String str=stackValues.getValue();
                        
                       List<String> val= push.values;
                       
                       if(val==null)
                       {
                           for(RTLNumber s:pushRegister.get(push.source))
                                {
                                    String str1= gammaSet.get( s.toHexString());
                             
                              List<String> oStack=new ArrayList();
                              
                              oStack.add(str1);
                              
                             
                              
                              oStack.add(str);
                              
                             String ruleID="R"+allCrules.size()+allNrules.size();

                            normalPDSRule pushIns=new normalPDSRule(start, to,str, oStack,ruleID);

                            allNrules.put(ruleID, pushIns);
                            
                            ls.add(ruleID);
                            
                            intialSet.add(ruleID);
                                }
                       
                       }
                       else{
                        for(int n=0;n<val.size();n++)
                        {
                        
                            List<String> oStack=new ArrayList();
                            
                             String str1=this.gammaSet.get(val.get(n));

                            oStack.add(str1);
                            
                             

                            oStack.add(str);

                            String ruleID="R"+allCrules.size()+allNrules.size();

                            normalPDSRule pushIns=new normalPDSRule(start, to,str, oStack,ruleID);

                            allNrules.put(ruleID, pushIns);
                            
                            ls.add(ruleID);
                            
                            intialSet.add(ruleID);
                        }
                       }
                    }
                    
                    // addrRulesRelation.put(push.source, ls);
                    if(!addrRulesRelation.containsKey(push.source))
                
                         addrRulesRelation.put(push.source, ls);
                else
                {
                    transList=addrRulesRelation.get(push.source);
                    
                    transList.addAll(ls);
                    
                    addrRulesRelation.put(push.source, transList);
                }
            }
            
           //AbsoluteAddress intialAddress= program.getCFG().getEntryPoint().getAddress();
           
           
          // this.initialControlLoc=addressConLocation.get(intialAddress);
           
          
           AbsoluteAddress initialAddress= locationAddressMap.get(this.initialControlLoc);
           
          

          if(gammaSet.containsKey( program.getInstruction(initialAddress).getOperand(0).toString()))
                         { 
                             if(gammaSet.containsKey(program.getInstruction(initialAddress).getOperand(0).toString()))
                             this.initialStackValue= gammaSet.get( program.getInstruction(initialAddress).getOperand(0).toString());  
                             System.out.print(this);
                         }
                 else
                 {
                     String s="r"+gammaSet.size();
                     String initialInstr=program.getInstruction(initialAddress).toString();
                     gammaSet.put( program.getInstruction(initialAddress).getOperand(0).toString(),s);

                     this.initialStackValue=s;            }
             
           
         
        }
        
        public void computeGammaSet( Map<AbsoluteAddress, Set<RTLNumber>> pushRegister)
        {
            //Iterator<AbsoluteAddress, Set<RTLNumber>> it=pushRegister.entrySet().iterator();
            for(Map.Entry<AbsoluteAddress, Set<RTLNumber>> entry:pushRegister.entrySet())
            {
                Set<RTLNumber> values=entry.getValue();
                
                for(RTLNumber s:values)
                {
                    if(!gammaSet.containsKey(s.toHexString()))
                    {
                        String id="r"+gammaSet.size();
                       gammaSet.put(s.toHexString(), id);
                    }
                }

             
            }
            for(int i=0;i<returnAddr.size();i++)
            {
               if(!gammaSet.containsKey(returnAddr.get(i)))
                    {
                        String id="r"+gammaSet.size();
                      gammaSet.put(returnAddr.get(i).toNumericConstant().toHexString(), id);
                    }  
            }
            
            System.out.print("The set of Gamma is computed."+'\n');
        }
	
	// Does not write a real graph, but still fits best into this class  
	public void writeDisassembly(String filename) {
		logger.info("Writing assembly file to " + filename);
                
                System.out.printf("Translating program to SM-PDS"+'\n');

		SetMultimap<AbsoluteAddress, CFAEdge> branchEdges = HashMultimap.create(); 
		SetMultimap<AbsoluteAddress, CFAEdge> branchEdgesRev = HashMultimap.create(); 
		if (!Options.noGraphs.getValue()) {
			for (CFAEdge e : program.getCFG().getEdges()) {
				AbsoluteAddress sourceAddr = e.getSource().getAddress(); 
                                if(!addressConLocation.containsKey(sourceAddr))
                                {
                                    int size=addressConLocation.size();
                                    addressConLocation.put(sourceAddr, "p"+size);
                                    locationAddressMap.put("p"+size, sourceAddr);
                                }
                                
				AbsoluteAddress targetAddr = e.getTarget().getAddress();
                                if(!addressConLocation.containsKey(targetAddr))
                                {
                                     int size=addressConLocation.size();
                                    addressConLocation.put(targetAddr, "p"+size);
                                    locationAddressMap.put("p"+size, targetAddr);
                                }
                                
				if (program.getInstruction(sourceAddr) instanceof BranchInstruction && !sourceAddr.equals(targetAddr)) {
					branchEdges.put(sourceAddr, e);
					branchEdgesRev.put(targetAddr, e);
				}
			}
		}
                
                gobalBranchEdges=branchEdges;
		
		try {
			FileWriter out = new FileWriter(filename);
                        
                       // FileWriter oWriter=new FileWriter(filename+"_smpds"); // for writing SM-PDS
                        
			
			VpcTrackingAnalysis vpcAnalysis = (VpcTrackingAnalysis)AnalysisManager.getInstance()
					.getAnalysis(VpcTrackingAnalysis.class);
			
			for (Map.Entry<AbsoluteAddress,Instruction> entry : program.getAssemblyMap().entrySet()) {
				AbsoluteAddress pc = entry.getKey();
				Instruction instr = entry.getValue();
				StringBuilder sb = new StringBuilder();
                                
                                StringBuilder pds=new StringBuilder();
                                
                                
				SymbolFinder symFinder = program.getModule(pc).getSymbolFinder();
				if (symFinder.hasSymbolFor(pc)) {
					sb.append(Characters.NEWLINE);
					sb.append(symFinder.getSymbolFor(pc));
                                        this.initialControlLoc=addressConLocation.get(pc);
					sb.append(":").append(Characters.NEWLINE);
                                       
                                        
				}
				if (vpcAnalysis != null) {
					ValueContainer vpc = vpcAnalysis.getVpc(new RTLLabel(pc));
					sb.append(vpc == null ? "" : vpc);
					sb.append("\t");
				}
				
				sb.append(pc).append(":\t");
				sb.append(instr.toString(pc.getValue(), symFinder));
                                
                                /**** Compute Gamma, the second case. i.e. push exp, all the values of exp.***/
				if(instr.toString(pc.getValue(), symFinder).contains("push"))
                                {
                                    Operand exp=instr.getOperand(0);
                                    
                                    long targetValue=pc.getValue()+instr.getSize();
                                       
                                    AbsoluteAddress t=new AbsoluteAddress(targetValue);
                                    
                                    if(exp instanceof Immediate)
                                    {
                                        List<String> ls=new ArrayList<String>();
                                        ls.add(((Immediate) exp).toString());
                                        
                                        pushList pl=new pushList(pc,t,ls);
                                        
                                        pushlist.add(pl);
                                        
                                        if(!gammaSet.containsKey(((Immediate) exp).toString()))
                                            {
                                                String id="r"+gammaSet.size();
                                              gammaSet.put(((Immediate) exp).toString(), id);
                                            }  
                                        
                                        expValues.add(((Immediate) exp).toString());
                                    }
                                    
                                    else if(exp instanceof X86MemoryOperand)
                                    {
                                        List<String> ls=new ArrayList<String>();
                                        ls.add(((X86MemoryOperand) exp).toString());
                                        
                                        pushList pl=new pushList(pc,t,ls);
                                        
                                        pushlist.add(pl);
                                        
                                         if(!gammaSet.containsKey(((X86MemoryOperand) exp).toString()))
                                            {
                                                String id="r"+gammaSet.size();
                                              gammaSet.put(((X86MemoryOperand) exp).toString(), id);
                                            } 
                                        
                                        expValues.add(((X86MemoryOperand) exp).toString());
                                    }
                                    
                                    else if(exp instanceof AbsoluteAddress)
                                    {
                                        List<String> ls=new ArrayList<String>();
                                        ls.add(((AbsoluteAddress) exp).toString());
                                        
                                        pushList pl=new pushList(pc,t,ls);
                                        
                                        pushlist.add(pl);
                                        
                                         if(!gammaSet.containsKey(((AbsoluteAddress) exp).toString()))
                                            {
                                                String id="r"+gammaSet.size();
                                              gammaSet.put(((AbsoluteAddress) exp).toString(), id);
                                            } 
                                        
                                        expValues.add(((AbsoluteAddress) exp).toString());
                                    }
                                    
                                    else if(exp instanceof X86Register)
                                    {
                                        List<String> ls=new ArrayList<String>();
                                        pushInstrList.put(pc, (X86Register) exp);
                                        pushList pl=new  pushList(pc,t,null);
                                         pushlist.add(pl);
                                        
                                     //   exp.toString(targetValue, symFinder)
                                       /* List<String> ls=new ArrayList<String>();
                                        ls.add(((X86MemoryOperand) exp).toString());
                                        
                                        pushList pl=new pushList(pc,t,ls);
                                        
                                        pushlist.add(pl);
                                        
                                        expValues.add(((Immediate) exp).toString());*/
                                    }
                                    else 
                                    {
                                        List<String> ls=new ArrayList<String>();
                                        ls.add(( exp).toString());
                                        
                                        pushList pl=new pushList(pc,t,ls);
                                        
                                        pushlist.add(pl);
                                        
                                         if(!gammaSet.containsKey(( exp).toString()))
                                            {
                                                String id="r"+gammaSet.size();
                                              gammaSet.put((exp).toString(), id);
                                            } 
                                        
                                        expValues.add(( exp).toString());
                                    }
                                    
                                    String s=instr.getOperand(0).toString();
                                    instr.getDescription();
                                }
                                
                                else if(instr.toString(pc.getValue(), symFinder).contains("mov"))
                                        {
                                       if(instr.getOperand(1) instanceof AbsoluteAddress){
                                         if(program.getAssemblyMap().containsKey( (AbsoluteAddress)instr.getOperand(1))) //This means the operand is an address that strores instruction
                                                {
                                                    changingInstrList.put(pc, instr); 
                                                }
                                       }
                                         else
                                             restInstrList.put(pc, new AbsoluteAddress(pc.getValue()+instr.getSize()));
                                        }
                                /***** end the computation***/
                               
                                else if (instr instanceof BranchInstruction) {
					Set<CFAEdge> targets = branchEdges.get(pc);
					sb.append("\t; targets: ");
                                        List<AbsoluteAddress> ls=new ArrayList<AbsoluteAddress>();
					if (targets.isEmpty()) {
						sb.append("unresolved");
					} else {
						boolean first = true;
						for (CFAEdge e : targets) {
							if (first) first = false;
							else sb.append(", ");
                                                        
                                        /****** compute the Gamma where the situation is a call function***/
                                                  if(instr instanceof X86CallInstruction) // call
                                                 {
                                                     if( ((X86CallInstruction) instr).getBranchDestination() instanceof X86PCRelativeAddress)
                                                     {
                                                         X86PCRelativeAddress relativeTarget= (X86PCRelativeAddress)((X86CallInstruction) instr).getBranchDestination();
                                                        long relativeValue=relativeTarget.getDisplacement();
                                                         long absoluteVaue=pc.getValue()+instr.getSize();
                                                        AbsoluteAddress absoluteAddr=new AbsoluteAddress(absoluteVaue);
                                                        callInstruction callI=new callInstruction(pc,e.getTarget().getAddress(),absoluteAddr);                                                   
                                                       //int size= instr.getSize();
                                        
                                                         callList.add(callI);
                                                          /**** Compute Gamma for the first case i.e. call instruction ,return address*/
                                                          returnAddr.add(absoluteAddr);
                  // String to=SMPDS.addressConLocation.get((X86PCRelativeAddress) (X86CallInstruction) instr).getBranchDestination());
                                                        }
               
                                                    }
                                                  
                                                  else
                                                  {
                                                      ls.add(e.getTarget().getAddress());
                                                     
                                                      
                                                  }
                                                 
                                                 
                                                  
							sb.append(e.getTarget().getAddress());
							sb.append('(').append(e.getKind()).append(')');
						}
                                                
                                                if(instr instanceof X86RetInstruction)
                                                {
                                                    retInstrList.put(pc,  ls);
                                                }
                                                
                                                if(instr instanceof X86JmpInstruction && instr instanceof X86CondJmpInstruction) //jm[
                                                 {
                                                     //Operand oper= ((X86JmpInstruction) instr).getBranchDestination();
                                                     jmpInstrList.put(pc, ls);
                                                     
                                                }
					}
				}
                               
                                else if(instr.toString(pc.getValue(), symFinder).contains("pop")) //pop
                                {
                                    popInstrList.put(pc, new AbsoluteAddress(pc.getValue()+instr.getSize()));
                                }
                                else  // the rest
                                {
                                    restInstrList.put(pc, new AbsoluteAddress(pc.getValue()+instr.getSize()));
                                }

                                

				if (branchEdgesRev.containsKey(pc)) {
					Set<CFAEdge> referers = branchEdgesRev.get(pc);
					sb.append("\t; from: ");
					boolean first = true;
					for (CFAEdge e : referers) {
						if (first) first = false;
						else sb.append(", ");
						sb.append(e.getSource().getAddress());
						sb.append('(').append(e.getKind()).append(')');
					}
				}
				
				
				sb.append(Characters.NEWLINE);
				if (instr instanceof ReturnInstruction) sb.append(Characters.NEWLINE);
				out.write(sb.toString());
			}
			out.close();

		} catch (IOException e) {
			logger.fatal(e);
			return;
		}
	}
	
	public void writeAssemblyVCFG(String filename, VpcCfgReconstruction vCfgRec) {
		AsmCFG cfg = vCfgRec.getTransformedAsmCfg();
		ControlFlowGraph ilCfg = vCfgRec.getTransformedCfg();
		// Create dot file
		GraphWriter gwriter = createGraphWriter(filename);
		if (gwriter == null) return;

		logger.info("Writing assembly CFG to " + gwriter.getFilename());
		try {
		for (Map.Entry<Location, Instruction> entry : cfg.getNodes().entrySet()) {
			Location l = entry.getKey();
			Instruction instr = entry.getValue();

			String nodeName = l.toString();
			String nodeLabel = program.getSymbolFor(l.getAddress());
			if (nodeLabel.length() > 20) nodeLabel = nodeLabel.substring(0, 20) + "...";
			
			if (instr != null) {
				String instrString = program.getInstructionString(l.getAddress(), instr);
				instrString = instrString.replace("\t", " ");
				gwriter.writeNode(nodeName, nodeLabel + "\\n" + instrString, getNodeProperties(ilCfg, l));
			} else {
				gwriter.writeNode(nodeName, nodeLabel, getNodeProperties(ilCfg, l));
			}
		}

		for (Map.Entry<Location, Pair<Location, Object>> entry : cfg.getEdges().entries()) {
			Location source = entry.getKey();
			Location target = entry.getValue().getLeft();
			Object label = entry.getValue().getRight();
			
			gwriter.writeEdge(source.toString(), 
					target.toString(), 
					label.toString());
		}

		gwriter.close();
		
		} catch (IOException e) {
			logger.error("Cannot write to output file", e);
			return;
		}

	}

	public  void writeAssemblyCFG(ControlFlowGraph cfg, String filename,List<String> prop, List<String> negProp) { //modifed by xin to generate SM-PDS transitions.
		Set<CFAEdge> edges = new HashSet<CFAEdge>(); 
		Set<RTLLabel> nodes = new HashSet<RTLLabel>();
		for (CFAEdge e : cfg.getEdges()) {
			AbsoluteAddress sourceAddr = e.getSource().getAddress(); 
			AbsoluteAddress targetAddr = e.getTarget().getAddress();
			if (!sourceAddr.equals(targetAddr)) {
				edges.add(e);
				nodes.add(e.getSource().getLabel());
				nodes.add(e.getTarget().getLabel());
			}
		}
		
		// Create dot file
		GraphWriter gwriter = createGraphWriter(filename);
		if (gwriter == null) return ;
                
               //  Map<String,List<String>> propList=new  HashMap<String,List<String>>();
                 
                

		logger.info("Writing assembly CFG to " + gwriter.getFilename());
		try {
			for (RTLLabel node : nodes) {
				AbsoluteAddress nodeAddr = node.getAddress();
				Instruction instr = program.getInstruction(nodeAddr);
				String nodeName = nodeAddr.toString();
				String nodeLabel = program.getSymbolFor(nodeAddr);
                               
				if (instr != null) {
					String instrString = program.getInstructionString(nodeAddr);
					instrString = instrString.replace("\t", " ");
					gwriter.writeNode(nodeName, nodeLabel + "\\n" + instrString, getNodeProperties(cfg, node));
				} else {
					gwriter.writeNode(nodeName, nodeLabel, getNodeProperties(cfg, node));
				}
                                
                                if(instr instanceof X86CallInstruction){
                                for(int i=0;i<prop.size();i++)
                                {
                                     List<String> ls=new ArrayList<String>();
                                     
                                     String str2=program.getInstructionString(nodeAddr).toLowerCase();
                                    if(str2.contains(prop.get(i).toLowerCase()))
                                    {
                                        if(propControlLoc.containsKey(prop.get(i)))
                                        {
                                            ls=propControlLoc.get(prop.get(i));
                                            
                                            if(!ls.contains(addressConLocation.get(nodeAddr))){
                                            
                                            ls.add(addressConLocation.get(nodeAddr));
                                            
                                            propControlLoc.put(prop.get(i), ls);
                                            }
                                        }
                                        else
                                        {
                                            ls.add(addressConLocation.get(nodeAddr));
                                            
                                             propControlLoc.put(prop.get(i), ls);
                                        }
                                    }
                                }
                                
                                for(int i=0;i<negProp.size();i++)
                                {
                                     List<String> ls=new ArrayList<String>();
                                     
                                     String str2=program.getInstructionString(nodeAddr).toLowerCase();
                                    if(str2.contains(negProp.get(i).toLowerCase()))
                                    
                                        if(negPropControlLoc.containsKey(prop.get(i)))
                                        {
                                            ls=negPropControlLoc.get(prop.get(i));
                                            
                                            if(!ls.contains(addressConLocation.get(nodeAddr))){
                                            
                                            ls.add(addressConLocation.get(nodeAddr));
                                            
                                            negPropControlLoc.put(prop.get(i), ls); //This is for valuation where the propostion is ture on the control location excepts 
                                            }
                                        }
                                        else
                                        {
                                            ls.add(addressConLocation.get(nodeAddr));
                                            
                                             negPropControlLoc.put(prop.get(i), ls);
                                        }
                                    }
                               
                                }
			}

			for (CFAEdge e : edges) {
				if (e.getKind() == null) logger.error("Null kind? " + e);
				AbsoluteAddress sourceAddr = e.getSource().getAddress(); 
				AbsoluteAddress targetAddr = e.getTarget().getAddress();
				
				String label = null;
				Instruction instr = program.getInstruction(sourceAddr);
				
				if (instr instanceof BranchInstruction) {
					BranchInstruction bi = (BranchInstruction)instr;
					if (bi.isConditional()) {
						// Get the original goto from the program (not the converted assume) 
						RTLStatement rtlGoto = program.getStatement(e.getSource().getLabel());
						
						// If this is the fall-through edge, output F, otherwise T
						label = targetAddr.equals(rtlGoto.getNextLabel().getAddress()) ? "F" : "T";
					}
				}
				
				gwriter.writeEdge(sourceAddr.toString(), 
						targetAddr.toString(), 
						label,
						e.getKind().equals(CFAEdge.Kind.MAY) ? Color.BLACK : Color.GREEN);
			}

			gwriter.close();
		} catch (IOException e) {
			logger.error("Cannot write to output file", e);
			return ;
		}
		//return propList;
	}
	
	public void writeAssemblyBasicBlockGraph(ControlFlowGraph cfg, String filename) {
		logger.info("Writing assembly basic block graph to " + filename);
		writeAssemblyBBCFG(cfg, filename);
	}
	
	public void writeTopologyGraph(ControlFlowGraph cfg, String filename) {
		logger.info("Writing toplogy graph to " + filename);
		writeTopologicalBBCFG(cfg, filename);
	}
	
	public void writeControlFlowAutomaton(ControlFlowGraph cfg, String filename) {
		writeControlFlowAutomaton(cfg, filename, (ReachedSet)null);
	}

	public void writeControlFlowAutomaton(ControlFlowGraph cfg, String filename, ReachedSet reached) {
		logger.info("Writing CFA to " + filename);
		writeControlFlowGraph(cfg, filename, reached);
	}

	public void writeVpcBasicBlockGraph(String filename, VpcCfgReconstruction vCfgRec) {
		
		ControlFlowGraph vCfg = vCfgRec.getTransformedCfg();		
		// Create dot file
		GraphWriter gwriter = createGraphWriter(filename);
		if (gwriter == null) return;

		logger.info("Writing VPC-lifted basic block graph to " + gwriter.getFilename());
		try {
			for (Location loc : vCfg.getBasicBlockNodes()) {
				VpcLocation vpcLoc = (VpcLocation)loc;
				
				RTLLabel nodeAddr = vpcLoc.getLabel();
				String nodeName = vpcLoc.toString();
				StringBuilder labelBuilder = new StringBuilder();
				String locLabel = program.getSymbolFor(nodeAddr);
				if (locLabel.length() > 20) locLabel = locLabel.substring(0, 20) + "...";
				labelBuilder.append(locLabel).append(" @ ").append(vpcLoc.getVPC()).append("\\n");
				
				BasicBlock bb = vCfg.getBasicBlock(vpcLoc);

				for (RTLStatement stmt : bb) {
					labelBuilder.append(stmt.toString() + "\\l");
				}
				gwriter.writeNode(nodeName, labelBuilder.toString(), getNodeProperties(vCfg, vpcLoc));
			}

			for (CFAEdge e : vCfg.getBasicBlockEdges()) {
				VpcLocation sourceAddr = (VpcLocation)e.getSource(); 
				VpcLocation targetAddr = (VpcLocation)e.getTarget();
				if (e.getTransformer() instanceof RTLSkip)
					gwriter.writeEdge(sourceAddr.toString(), 
							targetAddr.toString());
				else
					gwriter.writeEdge(sourceAddr.toString(), 
							targetAddr.toString(), 
							e.getTransformer().toString());
			}

			gwriter.close();
		} catch (IOException e) {
			logger.error("Cannot write to output file", e);
			return;
		}
	}


	
	public void writeART(String filename, AbstractReachabilityTree art) {
		Map<String,String> startNode = new HashMap<String, String>();
		Map<String,String> endNode = new HashMap<String, String>();
		startNode.put("color", "green");
		startNode.put("style", "filled,bold");
		endNode.put("color", "red");
		endNode.put("style", "filled,bold");
	
		// Create dot file
		GraphWriter gwriter = createGraphWriter(filename);
		if (gwriter == null) return;
	
		logger.info("Writing ART to " + gwriter.getFilename());
		try {
			Deque<AbstractState> worklist = new LinkedList<AbstractState>();
			//Set<AbstractState> visited = new HashSet<AbstractState>();
			worklist.add(art.getRoot());
			//visited.addAll(worklist);
			while (!worklist.isEmpty()) {
				AbstractState curState = worklist.removeFirst();
	
				String nodeName = curState.getIdentifier();
				Map<String, String> properties = null;
				if (curState == art.getRoot())
					properties = startNode;
				if (program.getStatement((RTLLabel)curState.getLocation()) instanceof RTLHalt)
					properties = endNode;
				StringBuilder nodeLabel = new StringBuilder();
				nodeLabel.append(curState.getIdentifier());
	
				gwriter.writeNode(nodeName, nodeLabel.toString(), properties);
	
				for (Pair<CFAEdge, AbstractState> sPair : art.getChildren(curState)) {
					AbstractState nextState = sPair.getRight();
					//if (!visited.contains(nextState)) {
					worklist.add(nextState);
					//visited.add(nextState);
					gwriter.writeEdge(nodeName, nextState.getIdentifier());
					//}
				}
			}			
			gwriter.close();
		} catch (IOException e) {
			logger.error("Cannot write to output file", e);
			return;
		}
	
	}

	public void writeCallGraph(String filename, SetMultimap<Location, Location> callGraph) {
		// Create dot file
		GraphWriter gwriter = createGraphWriter(filename);
		if (gwriter == null) return;
		
		Set<Location> nodes = new HashSet<Location>();
		
		logger.info("Writing callgraph to " + gwriter.getFilename());
		try {
			for (Map.Entry<Location, Location> e : callGraph.entries()) {
				nodes.add(e.getKey());
				nodes.add(e.getValue());
				gwriter.writeEdge(e.getKey().toString(), 
						e.getValue().toString());
			}
			
			for (Location node : nodes) {
				gwriter.writeNode(node.toString(), node.toString(), getNodeProperties(null, node));
			}
	
			gwriter.close();
		} catch (IOException e) {
			logger.error("Cannot write to output file", e);
			return;
		}		
	}

	private GraphWriter createGraphWriter(String filename) {
		try {
			if (Options.graphML.getValue()) {
				return new GraphMLWriter(filename);
			} else {
				return new GraphvizWriter(filename);
			}
		} catch (IOException e) {
			logger.error("Cannot open output file!", e);
			return null;
		}
	}

	private Map<String,String> getNodeProperties(ControlFlowGraph cfg, Location loc) {
		RTLStatement curStmt = program.getStatement(loc.getLabel());
		Map<String,String> properties = new HashMap<String, String>();
	
		if (curStmt != null) {			
			AbsoluteAddress curAddr = loc.getAddress();
			if (program.isStub(curAddr) || program.getHarness().contains(curAddr)) {
				properties.put("color", "lightgrey");
				properties.put("fillcolor", "lightgrey");
			}
	
			if (program.getUnresolvedBranches().contains(loc.getLabel())) {
				properties.put("fillcolor", "red");
			}
			
			if (mustLeaves.contains(loc.getLabel())) {
				properties.put("fillcolor", "green");
			}
	
			if (loc.equals(cfg.getEntryPoint())) {
				properties.put("color", "green");
				properties.put("style", "filled,bold");
			} else if (curStmt instanceof RTLHalt) {
				properties.put("color", "orange");
				properties.put("style", "filled,bold");
			}
		} else {
			logger.info("No real statement for location " + loc);
		}
	
		return properties;
	}
	
	private void writeControlFlowGraph(ControlFlowGraph cfg, String filename, ReachedSet reached) {
		// Create dot file
		GraphWriter gwriter = createGraphWriter(filename);
		if (gwriter == null) return;
	
		try {
			for (Location node : cfg.getNodes()) {
				String nodeName = node.toString();
				StringBuilder labelBuilder = new StringBuilder();
				labelBuilder.append(nodeName);
				if (reached != null) {
					labelBuilder.append("\n");
					if (reached.where(node).isEmpty()) {
						logger.warn("No reached states for location " + node);
					}
					for (AbstractState a : reached.where(node)) {
						labelBuilder.append(a.toString());
						labelBuilder.append("\n");
					}
				}
				gwriter.writeNode(nodeName, labelBuilder.toString(), getNodeProperties(cfg, node));
			}
	
			for (CFAEdge e : cfg.getEdges()) {
				if (e.getKind() == null) logger.error("Null kind? " + e);
				gwriter.writeEdge(e.getSource().toString(), 
						e.getTarget().toString(), 
						e.getTransformer().toString(),
						e.getKind().equals(CFAEdge.Kind.MAY) ? Color.BLACK : Color.GREEN);
			}
	
			gwriter.close();
		} catch (IOException e) {
			logger.error("Cannot write to output file", e);
			return;
		}
	}

	private void writeAssemblyBBCFG(ControlFlowGraph cfg, String filename) {
		// Create dot file
		GraphWriter gwriter = createGraphWriter(filename);
		if (gwriter == null) return;
		
		TreeMap<Location, BasicBlock> blockMap = new TreeMap<Location, BasicBlock>();
		blockMap.putAll(cfg.getBasicBlocks());
	
		try {
			//for (Map.Entry<Location, BasicBlock> entry : cfg.getBasicBlocks().entrySet()) {
			for (Map.Entry<Location, BasicBlock> entry : blockMap.entrySet()) {
				
				Location nodeLoc = entry.getKey();
				BasicBlock bb = entry.getValue();
				
				String nodeName = nodeLoc.toString();
				StringBuilder labelBuilder = new StringBuilder();
				String locLabel = program.getSymbolFor(nodeLoc.getAddress());
				if (locLabel.length() > 20) locLabel = locLabel.substring(0, 20) + "...";
				labelBuilder.append(locLabel).append("\\n");
	
				for (Iterator<AbsoluteAddress> addrIt = bb.addressIterator(); addrIt.hasNext();) {
					AbsoluteAddress curAddr = addrIt.next();
					Instruction instr = program.getInstruction(curAddr);
					if (instr != null) {
						String instrString = program.getInstructionString(curAddr);
						instrString = instrString.replace("\t", " ");
						labelBuilder.append(instrString).append("\\l");
					} else {
						//labelBuilder.append(curAddr.toString() + "\\l");
					}
				}
				
				gwriter.writeNode(nodeName, labelBuilder.toString(), getNodeProperties(cfg, nodeLoc));
			}
			
			for (CFAEdge e : cfg.getBasicBlockEdges()) {
				if (e.getKind() == null) logger.error("Null kind? " + e);
				Location sourceLoc = e.getSource(); 
				Location targetLoc = e.getTarget();
				RTLStatement stmt = (RTLStatement)e.getTransformer();
				
				String label = null;
				RTLLabel lastLoc = stmt.getLabel();
				Instruction instr = program.getInstruction(lastLoc.getAddress());
				
				boolean weak = false;
				
				// Get the original instruction from the program, i.e., possibly a goto and not the converted assume 
				RTLStatement origStmt = program.getStatement(lastLoc);
				if (origStmt instanceof RTLGoto) {

					if (instr instanceof BranchInstruction) {
						BranchInstruction bi = (BranchInstruction)instr;
						if (bi.isConditional()) {
							// If the assume in the edge has the same nextlabel as Goto, then it's the fall-through
							label = stmt.getNextLabel().equals(origStmt.getNextLabel()) ? "F" : "T";
						}
					}
					
					switch (((RTLGoto)origStmt).getType()) {
					case CALL: case RETURN:
						if (stmt.getNextLabel().equals(origStmt.getNextLabel())) {
							label = "call return";
						} else {
							weak = true;
						}
					default: // nothing
					}
				}
				
				// Only draw edges as weak if we generated fall-through edges
				if (Options.procedureAbstraction.getValue() != 1)
					weak = false;

				gwriter.writeEdge(
						sourceLoc.toString(), 
						targetLoc.toString(), 
						label,
						e.getKind().equals(CFAEdge.Kind.MAY) ? Color.BLACK : Color.GREEN,
						weak
						);
	
			}
	
			gwriter.close();
		} catch (IOException e) {
			logger.error("Cannot write to output file", e);
			return;
		}
	}

	private void writeTopologicalBBCFG(ControlFlowGraph cfg, String filename) {
		// Create dot file
		GraphWriter gwriter = createGraphWriter(filename);
		if (gwriter == null) return;
	
		try {
			for (Map.Entry<Location, BasicBlock> entry : cfg.getBasicBlocks().entrySet()) {
				
				Location nodeLoc = entry.getKey();
				
				String nodeName = nodeLoc.toString();
				StringBuilder labelBuilder = new StringBuilder();
				String locLabel = program.getSymbolFor(nodeLoc.getAddress());
				if (locLabel.length() > 20) locLabel = locLabel.substring(0, 20) + "...";
				labelBuilder.append(locLabel).append("\\n");
	
				gwriter.writeNode(nodeName, labelBuilder.toString(), getNodeProperties(cfg, nodeLoc));
			}
			
			for (CFAEdge e : cfg.getBasicBlockEdges()) {
				if (e.getKind() == null) logger.error("Null kind? " + e);
				Location sourceLoc = e.getSource(); 
				Location targetLoc = e.getTarget();
				RTLStatement stmt = (RTLStatement)e.getTransformer();
				
				String label = null;
				RTLLabel lastLoc = stmt.getLabel();
				Instruction instr = program.getInstruction(lastLoc.getAddress());
				
				if (instr instanceof BranchInstruction) {
					BranchInstruction bi = (BranchInstruction)instr;
					if (bi.isConditional()) {
						// Get the original goto from the program (not the converted assume) 
						RTLStatement rtlGoto = program.getStatement(lastLoc);
						
						// If this is the fall-through edge, output F, otherwise T
						//label = targetLoc.getAddress().equals(rtlGoto.getNextLabel().getAddress()) ? "F" : "T";
						// If the assume in the edge has the same nextlabel as Goto, then it's the fall-through
						label = stmt.getNextLabel().equals(rtlGoto.getNextLabel()) ? "F" : "T";
					}
				}
				
				gwriter.writeEdge(
						sourceLoc.toString(), 
						targetLoc.toString(), 
						label,
						e.getKind().equals(CFAEdge.Kind.MAY) ? Color.BLACK : Color.GREEN
						);
	
			}
	
			gwriter.close();
		} catch (IOException e) {
			logger.error("Cannot write to output file", e);
			return;
		}
	}

}
